import { useEffect, useState } from 'react'
import './App.css'
import { useMsal } from '@azure/msal-react'
import { loginRequest } from './auth/msal'

type Subject = { id: string; type: 'CAPOFILA' | 'CONSORZIO'; name: string }
type DocumentMeta = { id: string; filename: string; year?: number }

function App() {
  const { instance, accounts } = useMsal()
  const account = accounts[0]
  const [spaces, setSpaces] = useState<Subject[]>([])
  const [docs, setDocs] = useState<DocumentMeta[]>([])
  const [currentSpace, setCurrentSpace] = useState<string | null>(null)

  useEffect(() => {
    if (!account) return
    const token = localStorage.getItem('access_token') || ''
    fetch(`${import.meta.env.VITE_API_BASE}/v1/spaces`, {
      headers: { Authorization: `Bearer ${token}` },
    })
      .then(r => r.json())
      .then(setSpaces)
      .catch(() => {})
  }, [account])

  useEffect(() => {
    if (!account || !currentSpace) return
    const token = localStorage.getItem('access_token') || ''
    fetch(`${import.meta.env.VITE_API_BASE}/v1/subjects/${currentSpace}/documents`, {
      headers: { Authorization: `Bearer ${token}` },
    })
      .then(r => r.json())
      .then(setDocs)
      .catch(() => {})
  }, [account, currentSpace])

  async function login() {
    const res = await instance.loginPopup(loginRequest)
    const token = await instance.acquireTokenSilent({ ...loginRequest, account: res.account })
    localStorage.setItem('access_token', token.accessToken)
  }

  async function logout() {
    await instance.logoutPopup()
    localStorage.removeItem('access_token')
  }

  async function onUpload(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0]
    if (!file || !currentSpace) return
    const form = new FormData()
    form.append('file', file)
    const token = localStorage.getItem('access_token') || ''
    const res = await fetch(`${import.meta.env.VITE_API_BASE}/v1/subjects/${currentSpace}/documents`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${token}` },
      body: form,
    })
    if (res.ok) setCurrentSpace(currentSpace)
  }

  return (
    <div className="App">
      <header style={{ display: 'flex', justifyContent: 'space-between' }}>
        <h2>SISTEMA-X</h2>
        <div>
          {!account ? (
            <button onClick={login}>Accedi</button>
          ) : (
            <button onClick={logout}>Esci</button>
          )}
        </div>
      </header>

      {account && (
        <div style={{ display: 'flex', gap: 24 }}>
          <aside style={{ minWidth: 280 }}>
            <h3>Spazi</h3>
            <ul>
              {spaces.map(s => (
                <li key={s.id}>
                  <button onClick={() => setCurrentSpace(s.id)}>{s.name} ({s.type})</button>
                </li>
              ))}
            </ul>
          </aside>
          <main style={{ flex: 1 }}>
            <h3>Documenti {currentSpace ? `- ${currentSpace}` : ''}</h3>
            {currentSpace && (
              <>
                <input type="file" accept="application/pdf,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" onChange={onUpload} />
                <ul>
                  {docs.map(d => (
                    <li key={d.id}>
                      <a href={`${import.meta.env.VITE_API_BASE}/v1/documents/${d.id}/download`} target="_blank" rel="noreferrer">{d.filename}</a>
                      {d.year ? ` (anno ${d.year})` : ''}
                    </li>
                  ))}
                </ul>
              </>
            )}
          </main>
        </div>
      )}
    </div>
  )
}

export default App
