import { PublicClientApplication, type Configuration, EventType } from "@azure/msal-browser";

const msalConfig: Configuration = {
  auth: {
    clientId: import.meta.env.VITE_MSAL_CLIENT_ID,
    authority: `https://login.microsoftonline.com/${import.meta.env.VITE_MSAL_TENANT_ID}`,
    redirectUri: window.location.origin,
  },
  cache: { cacheLocation: "localStorage" },
};

export const msal = new PublicClientApplication(msalConfig);

msal.addEventCallback((event) => {
  if (event.eventType === EventType.LOGIN_SUCCESS && event.payload) {
    const account = (event.payload as any).account;
    msal.setActiveAccount(account);
  }
});

export const loginRequest = {
  scopes: ["openid", "profile", "email"],
};

