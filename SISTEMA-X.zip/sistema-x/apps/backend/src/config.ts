import dotenv from "dotenv";

dotenv.config();

export type AppRole = "CAPOFILA" | "CONSORZIO";

export const config = {
  port: Number(process.env.PORT || 4000),
  nodeEnv: process.env.NODE_ENV || "development",
  // OIDC / Entra ID
  oidc: {
    issuer: process.env.OIDC_ISSUER || "https://login.microsoftonline.com/REPLACE_TENANT_ID/v2.0",
    audience: process.env.OIDC_AUDIENCE || "api://REPLACE_API_APP_ID",
    jwksUri: process.env.OIDC_JWKS_URI || "https://login.microsoftonline.com/REPLACE_TENANT_ID/discovery/v2.0/keys",
    rolesClaim: process.env.OIDC_ROLES_CLAIM || "roles",
    subjectIdClaim: process.env.OIDC_SUBJECT_ID_CLAIM || "tid", // tenant or custom subject id claim
  },
  // Database
  db: {
    oracleUser: process.env.ORACLE_USER || "",
    oraclePassword: process.env.ORACLE_PASSWORD || "",
    oracleConnectString: process.env.ORACLE_CONNECT_STRING || "",
  },
  // Storage
  storageRoot: process.env.STORAGE_ROOT || "./storage",
  // Email
  email: {
    smtpHost: process.env.SMTP_HOST || "",
    smtpPort: Number(process.env.SMTP_PORT || 587),
    smtpUser: process.env.SMTP_USER || "",
    smtpPass: process.env.SMTP_PASS || "",
    from: process.env.EMAIL_FROM || "noreply@sistema-x.local",
  },
  // Audit
  auditLogPath: process.env.AUDIT_LOG_PATH || "./audit/audit.log",
};

export function isProd(): boolean {
  return config.nodeEnv === "production";
}

