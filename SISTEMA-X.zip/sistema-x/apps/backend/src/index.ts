import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import { documentsRouter } from "./routes/documents";
import { adminRouter } from "./routes/admin";
import { generationRouter } from "./routes/generation";
import { apiRouter } from "./routes/api";
import { ingestionRouter } from "./routes/ingestion";
import { spacesRouter } from "./routes/spaces";

dotenv.config();
const app = express();
app.use(cors());
app.use(express.json());

app.get("/health", (_req, res) => { res.json({ status: "ok" }); });

app.use("/v1", adminRouter);
app.use("/v1", documentsRouter);
app.use("/v1", generationRouter);
app.use("/v1", apiRouter);
app.use("/v1", ingestionRouter);
app.use("/v1", spacesRouter);

const port = process.env.PORT || 4000;
app.listen(port, () => { console.log(`Backend running on :${port}`); });
