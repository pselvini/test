import { v4 as uuidv4 } from "uuid";
import { DocumentMeta, MasterDataRow, Subject, UserProfile } from "../types";

// NOTE: For initial scaffold, use in-memory store. Replace with Oracle queries later.

const subjects = new Map<string, Subject>();
const users = new Map<string, UserProfile>();
const documents = new Map<string, DocumentMeta>();
const masterRows = new Map<string, MasterDataRow>();

export const repository = {
  // Subjects
  async upsertSubject(subject: Partial<Subject> & { id?: string }): Promise<Subject> {
    const id = subject.id || uuidv4();
    const now = new Date().toISOString();
    const entity: Subject = {
      id,
      type: subject.type!,
      name: subject.name || "",
      emailNotificationsEnabled: subject.emailNotificationsEnabled ?? true,
      signingPrivateKeyPem: subject.signingPrivateKeyPem,
      signingPublicKeyPem: subject.signingPublicKeyPem,
      createdAt: now,
    };
    subjects.set(id, entity);
    return entity;
  },
  async getSubject(id: string): Promise<Subject | undefined> {
    return subjects.get(id);
  },
  async listSubjects(): Promise<Subject[]> {
    return Array.from(subjects.values());
  },

  // Users
  async addUser(user: Omit<UserProfile, "id" | "createdAt">): Promise<UserProfile> {
    const id = uuidv4();
    const entity: UserProfile = { ...user, id, createdAt: new Date().toISOString() };
    users.set(id, entity);
    return entity;
  },
  async listUsersBySubject(subjectId: string): Promise<UserProfile[]> {
    return Array.from(users.values()).filter((u) => u.subjectId === subjectId);
  },

  // Documents
  async addDocument(doc: Omit<DocumentMeta, "id" | "createdAt">): Promise<DocumentMeta> {
    const id = uuidv4();
    const entity: DocumentMeta = { ...doc, id, createdAt: new Date().toISOString() };
    documents.set(id, entity);
    return entity;
  },
  async getDocument(id: string): Promise<DocumentMeta | undefined> {
    return documents.get(id);
  },
  async listDocumentsBySubject(subjectId: string): Promise<DocumentMeta[]> {
    return Array.from(documents.values()).filter((d) => d.subjectId === subjectId);
  },

  // Master data
  async upsertMasterRow(row: Omit<MasterDataRow, "id" | "createdAt"> & { id?: string }): Promise<MasterDataRow> {
    const id = row.id || uuidv4();
    const entity: MasterDataRow = { ...row, id, createdAt: new Date().toISOString() };
    masterRows.set(id, entity);
    return entity;
  },
  async listMasterRowsByYear(year: number): Promise<MasterDataRow[]> {
    return Array.from(masterRows.values()).filter((r) => r.year === year);
  },
  async listMasterRowsByYearAndConsortium(year: number, consortiumId: string): Promise<MasterDataRow[]> {
    return Array.from(masterRows.values()).filter((r) => r.year === year && r.consortiumId === consortiumId);
  },
};

