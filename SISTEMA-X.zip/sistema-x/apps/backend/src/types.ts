export type SubjectType = "CAPOFILA" | "CONSORZIO";

export interface Subject {
  id: string; // subject id (for CONSORZIO, unique per consortium)
  type: SubjectType;
  name: string;
  emailNotificationsEnabled: boolean;
  // PEM-encoded keys for signing (per subject)
  signingPrivateKeyPem?: string;
  signingPublicKeyPem?: string;
  createdAt: string;
}

export interface UserProfile {
  id: string;
  subjectId: string;
  firstName: string;
  lastName: string;
  email: string;
  receiveNotifications: boolean;
  createdAt: string;
}

export interface DocumentMeta {
  id: string;
  subjectId: string; // owner subject (space)
  filename: string;
  originalName: string;
  mimeType: string;
  size: number;
  year?: number;
  createdAt: string;
  uploadedByUserId: string;
  uploadedBySubjectId: string;
  storagePath: string;
  signaturePath?: string; // detached JWS signature file path
}

export interface MasterDataRow {
  id: string;
  year: number;
  consortiumId: string; // subjectId of CONSORZIO
  // domain-specific fields - generic key/value
  payload: Record<string, unknown>;
  createdAt: string;
  updatedAt?: string;
}

export interface AuthenticatedUser {
  userId: string; // from token sub or oid
  subjectId: string; // mapped subject (tenant/consorzio or capofila)
  roles: Array<"CAPOFILA" | "CONSORZIO">;
  email?: string;
  name?: string;
}

