import { Router, Request, Response } from "express";
import { authenticateOidc } from "../auth/oidc";
import { repository } from "../repository/repository";

export const spacesRouter = Router();

spacesRouter.get("/me", authenticateOidc, async (req: Request, res: Response) => {
  const user = (req as any).user as { userId: string; subjectId: string; roles: string[] };
  const subject = await repository.getSubject(user.subjectId);
  res.json({ user, subject });
});

// List spaces visible to current user
spacesRouter.get("/spaces", authenticateOidc, async (req: Request, res: Response) => {
  const user = (req as any).user as { subjectId: string; roles: string[] };
  const all = await repository.listSubjects();
  if (user.roles.includes("CAPOFILA")) return res.json(all);
  const mine = all.filter((s) => s.id === user.subjectId);
  res.json(mine);
});

