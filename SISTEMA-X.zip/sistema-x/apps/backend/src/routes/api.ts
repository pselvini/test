import { Router, Request, Response } from "express";
import { authenticateOidc } from "../auth/oidc";
import { AuthenticatedUser } from "../types";
import { repository } from "../repository/repository";
import { SignJWT, importPKCS8 } from "jose";

export const apiRouter = Router();

// Each consorzio can request signed JSON (JWS) with data for a specific year
apiRouter.get("/consorzi/:id/data/:year", authenticateOidc, async (req: Request, res: Response) => {
  const { id, year } = req.params;
  const y = Number(year);
  const subject = await repository.getSubject(id);
  if (!subject) return res.status(404).json({ error: "Unknown subject" });
  const user = (req as any).user as AuthenticatedUser;
  if (!user.roles.includes("CAPOFILA") && user.subjectId !== id) {
    return res.status(403).json({ error: "Forbidden" });
  }
  const rows = await repository.listMasterRowsByYearAndConsortium(y, id);
  const payload = { consortiumId: id, year: y, rows };
  if (!subject.signingPrivateKeyPem) return res.status(500).json({ error: "Subject key not configured" });
  const key = await importPKCS8(subject.signingPrivateKeyPem, "RS256");
  const jws = await new SignJWT(payload as any).setProtectedHeader({ alg: "RS256", typ: "JWS" }).setIssuedAt().sign(key);
  res.json({ jws });
});

