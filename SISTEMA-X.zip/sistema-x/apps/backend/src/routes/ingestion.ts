import { Router, Request, Response } from "express";
import fetch from "node-fetch";
import { authenticateOidc, requireRole } from "../auth/oidc";
import { repository } from "../repository/repository";
import { AuditService } from "../services/audit";

const audit = new AuditService();
export const ingestionRouter = Router();

// Ingest data from an external API and write to master table (by year)
ingestionRouter.post("/ingest", authenticateOidc, requireRole("CAPOFILA"), async (req: Request, res: Response) => {
  const { sourceUrl, year } = req.body || {};
  if (!sourceUrl || !year) return res.status(400).json({ error: "sourceUrl and year are required" });
  try {
    const r = await fetch(String(sourceUrl));
    if (!r.ok) throw new Error(`Fetch failed: ${r.status}`);
    const rows = (await r.json()) as Array<{ consortiumId: string; payload: any }>;
    let count = 0;
    for (const row of rows) {
      await repository.upsertMasterRow({ year: Number(year), consortiumId: row.consortiumId, payload: row.payload });
      count += 1;
    }
    await audit.write({ timestamp: new Date().toISOString(), action: "IMPORT_DATA", outcome: "SUCCESS", notes: `Imported ${count} rows for ${year}` });
    res.json({ imported: count });
  } catch (e: any) {
    await audit.write({ timestamp: new Date().toISOString(), action: "IMPORT_DATA", outcome: "FAILURE", notes: e?.message });
    res.status(500).json({ error: "Ingestion failed" });
  }
});

