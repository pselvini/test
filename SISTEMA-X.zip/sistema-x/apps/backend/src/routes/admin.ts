import { Router, Request, Response } from "express";
import { requireRole, authenticateOidc } from "../auth/oidc";
import { repository } from "../repository/repository";
import { generateSubjectKeyPair } from "../services/signing";
import { AuditService } from "../services/audit";

const audit = new AuditService();
export const adminRouter = Router();

// Create or update subject (CAPOFILA or CONSORZIO); generate keys if missing
adminRouter.post("/subjects", authenticateOidc, requireRole("CAPOFILA"), async (req: Request, res: Response) => {
  const body = req.body as { id?: string; type: "CAPOFILA" | "CONSORZIO"; name: string; emailNotificationsEnabled?: boolean };
  if (!body?.type || !body?.name) return res.status(400).json({ error: "Missing fields" });
  let signingPrivateKeyPem = undefined;
  let signingPublicKeyPem = undefined;
  if (!body.id) {
    const kp = await generateSubjectKeyPair();
    signingPrivateKeyPem = kp.privateKeyPem;
    signingPublicKeyPem = kp.publicKeyPem;
  }
  const subj = await repository.upsertSubject({
    id: body.id,
    type: body.type,
    name: body.name,
    emailNotificationsEnabled: body.emailNotificationsEnabled ?? true,
    signingPrivateKeyPem,
    signingPublicKeyPem,
  });
  await audit.write({ timestamp: new Date().toISOString(), action: "IMPORT_DATA", outcome: "SUCCESS", notes: `Subject upsert ${subj.id}` });
  res.json(subj);
});

// Seed user for a subject
adminRouter.post("/subjects/:subjectId/users", authenticateOidc, requireRole("CAPOFILA"), async (req: Request, res: Response) => {
  const { subjectId } = req.params;
  const { firstName, lastName, email, receiveNotifications } = req.body || {};
  if (!firstName || !lastName || !email) return res.status(400).json({ error: "Missing fields" });
  const user = await repository.addUser({ subjectId, firstName, lastName, email, receiveNotifications: !!receiveNotifications });
  res.status(201).json(user);
});

