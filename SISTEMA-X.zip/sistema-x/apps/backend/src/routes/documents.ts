import { Router, Request, Response } from "express";
import multer from "multer";
import path from "path";
import { authenticateOidc } from "../auth/oidc";
import { authorizeSubjectAccess, authorizeDocDownload } from "../auth/authorize";
import { repository } from "../repository/repository";
import { StorageService } from "../services/storage";
import { signBufferDetachedJws, writeSignatureFile } from "../services/signing";
import { AuditService } from "../services/audit";
import { EmailService } from "../services/email";

const upload = multer({ storage: multer.memoryStorage() });
const storage = new StorageService();
const audit = new AuditService();
const email = new EmailService();

export const documentsRouter = Router();

// List documents for a subject (space)
documentsRouter.get("/subjects/:subjectId/documents", authenticateOidc, authorizeSubjectAccess, async (req: Request, res: Response) => {
  const { subjectId } = req.params;
  const docs = await repository.listDocumentsBySubject(subjectId);
  res.json(docs);
});

// Upload document to a subject space (PDF, Excel), sign with subject key
documentsRouter.post(
  "/subjects/:subjectId/documents",
  authenticateOidc,
  authorizeSubjectAccess,
  upload.single("file"),
  async (req: Request, res: Response) => {
    try {
      const { subjectId } = req.params;
      const user = (req as any).user as { userId: string; subjectId: string };
      if (!req.file) return res.status(400).json({ error: "Missing file" });
      const mime = req.file.mimetype;
      if (!/(pdf|spreadsheet|excel|officedocument)/i.test(mime)) {
        return res.status(400).json({ error: "Only PDF or Excel allowed" });
      }
      const safeName = sanitizeFilename(req.file.originalname);
      const fullPath = await storage.saveFile(subjectId, safeName, req.file.buffer);
      const subj = await repository.getSubject(subjectId);
      const privateKey = subj?.signingPrivateKeyPem;
      let signaturePath: string | undefined;
      if (privateKey) {
        const jws = await signBufferDetachedJws(req.file.buffer, privateKey);
        signaturePath = fullPath + ".jws";
        await writeSignatureFile(signaturePath, jws);
      }
      const doc = await repository.addDocument({
        subjectId,
        filename: path.basename(fullPath),
        originalName: req.file.originalname,
        mimeType: mime,
        size: req.file.size,
        year: Number(req.body.year) || undefined,
        uploadedByUserId: user.userId,
        uploadedBySubjectId: user.subjectId,
        storagePath: fullPath,
        signaturePath,
      });
      await audit.write({ timestamp: new Date().toISOString(), action: "UPLOAD", outcome: "SUCCESS", subjectId, userId: user.userId, resource: fullPath });
      // If uploader is CAPOFILA and target is CONSORZIO, notify consortium users
      const uploaderRoles: string[] = (req as any).user.roles || [];
      if (uploaderRoles.includes("CAPOFILA") && subj?.type === "CONSORZIO") {
        const users = await repository.listUsersBySubject(subjectId);
        const recipients = users.filter((u) => u.receiveNotifications).map((u) => u.email);
        if (recipients.length > 0) {
          try {
            await email.send({
              to: recipients,
              subject: `Nuovo documento disponibile`,
              text: `E' stato caricato un nuovo documento nello spazio del consorzio ${subj.name}.`,
            });
            await audit.write({ timestamp: new Date().toISOString(), action: "NOTIFY_EMAIL", outcome: "SUCCESS", subjectId, resource: doc.filename });
          } catch (e: any) {
            await audit.write({ timestamp: new Date().toISOString(), action: "NOTIFY_EMAIL", outcome: "FAILURE", subjectId, notes: e?.message });
          }
        }
      }
      res.status(201).json(doc);
    } catch (err: any) {
      await audit.write({ timestamp: new Date().toISOString(), action: "UPLOAD", outcome: "FAILURE", notes: err?.message });
      res.status(500).json({ error: "Upload failed" });
    }
  }
);

// Download document by id
documentsRouter.get("/documents/:id/download", authenticateOidc, authorizeDocDownload, async (req: Request, res: Response) => {
  const doc = await repository.getDocument(req.params.id);
  if (!doc) return res.status(404).end();
  res.setHeader("Content-Type", doc.mimeType);
  res.setHeader("Content-Disposition", `attachment; filename="${doc.filename}"`);
  const fs = await import("fs");
  const stream = fs.createReadStream(doc.storagePath);
  stream.on("open", async () => {
    await audit.write({ timestamp: new Date().toISOString(), action: "DOWNLOAD", outcome: "SUCCESS", subjectId: doc.subjectId, resource: doc.storagePath });
  });
  stream.pipe(res);
});

function sanitizeFilename(name: string): string {
  return name.replace(/[^a-zA-Z0-9_.-]/g, "_");
}

