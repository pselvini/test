import { Router, Request, Response } from "express";
import ExcelJS from "exceljs";
import path from "path";
import { authenticateOidc, requireRole } from "../auth/oidc";
import { repository } from "../repository/repository";
import { StorageService } from "../services/storage";
import { signBufferDetachedJws, writeSignatureFile } from "../services/signing";
import { AuditService } from "../services/audit";
import { EmailService } from "../services/email";

const storage = new StorageService();
const audit = new AuditService();
const email = new EmailService();

export const generationRouter = Router();

// CAPOFILA triggers generation for a specific year for all consortia
generationRouter.post("/generate/:year", authenticateOidc, requireRole("CAPOFILA"), async (req: Request, res: Response) => {
  const year = Number(req.params.year);
  if (!year) return res.status(400).json({ error: "Invalid year" });
  const subjects = (await repository.listSubjects()).filter((s) => s.type === "CONSORZIO");
  const capofila = (await repository.listSubjects()).find((s) => s.type === "CAPOFILA");
  const privateKey = capofila?.signingPrivateKeyPem;
  const results: any[] = [];
  for (const consorzio of subjects) {
    const rows = await repository.listMasterRowsByYearAndConsortium(year, consorzio.id);
    const workbook = new ExcelJS.Workbook();
    const ws = workbook.addWorksheet("Dati");
    ws.columns = [
      { header: "Anno", key: "year", width: 10 },
      { header: "Consorzio", key: "consortiumId", width: 36 },
      { header: "Payload", key: "payload", width: 80 },
    ];
    for (const r of rows) {
      ws.addRow({ year: r.year, consortiumId: r.consortiumId, payload: JSON.stringify(r.payload) });
    }
    const buffer = await workbook.xlsx.writeBuffer();
    const timestamp = new Date().toISOString().replace(/[:.]/g, "");
    const filename = `report_${consorzio.id}_${year}_${timestamp}.xlsx`;
    const fullPath = await storage.saveFile(consorzio.id, filename, Buffer.from(buffer));
    let signaturePath: string | undefined;
    if (privateKey) {
      const jws = await signBufferDetachedJws(Buffer.from(buffer), privateKey);
      signaturePath = fullPath + ".jws";
      await writeSignatureFile(signaturePath, jws);
    }
    const doc = await repository.addDocument({
      subjectId: consorzio.id,
      filename: path.basename(fullPath),
      originalName: filename,
      mimeType: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      size: Buffer.byteLength(buffer),
      year,
      uploadedByUserId: (req as any).user.userId,
      uploadedBySubjectId: (req as any).user.subjectId,
      storagePath: fullPath,
      signaturePath,
    });
    // Notify all users of the consortium with notifications enabled
    const users = await repository.listUsersBySubject(consorzio.id);
    const recipients = users.filter((u) => u.receiveNotifications).map((u) => u.email);
    if (recipients.length > 0) {
      try {
        await email.send({
          to: recipients,
          subject: `Nuovo documento disponibile - Anno ${year}`,
          text: `E' stato generato un nuovo Excel per l'anno ${year} per il consorzio ${consorzio.name}.`,
        });
        await audit.write({ timestamp: new Date().toISOString(), action: "NOTIFY_EMAIL", outcome: "SUCCESS", subjectId: consorzio.id, resource: filename });
      } catch (e: any) {
        await audit.write({ timestamp: new Date().toISOString(), action: "NOTIFY_EMAIL", outcome: "FAILURE", subjectId: consorzio.id, notes: e?.message });
      }
    }
    results.push(doc);
  }
  await audit.write({ timestamp: new Date().toISOString(), action: "GENERATE_EXCEL", outcome: "SUCCESS", notes: `Generated for year ${year}` });
  res.json({ generated: results.length, documents: results });
});

