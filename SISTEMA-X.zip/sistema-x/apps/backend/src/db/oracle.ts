import oracledb from "oracledb";
import { config } from "../config";

export async function getOracleConnection() {
  const conn = await oracledb.getConnection({
    user: config.db.oracleUser,
    password: config.db.oraclePassword,
    connectString: config.db.oracleConnectString,
  });
  return conn;
}

export async function initOracleSession() {
  // Placeholder for session initialization (e.g., ALTER SESSION)
}

