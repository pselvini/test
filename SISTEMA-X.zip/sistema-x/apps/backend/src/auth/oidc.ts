import { IncomingHttpHeaders } from "http";
import jwksRsa from "jwks-rsa";
import jwt, { JwtHeader, SigningKeyCallback } from "jsonwebtoken";
import { Request, Response, NextFunction } from "express";
import { config } from "../config";
import { AuthenticatedUser } from "../types";

type DecodedToken = {
  iss: string;
  aud: string | string[];
  sub: string;
  tid?: string;
  preferred_username?: string;
  name?: string;
  email?: string;
  roles?: string[];
  [key: string]: unknown;
};

const jwksClient = jwksRsa({
  cache: true,
  jwksUri: config.oidc.jwksUri,
});

function getKey(header: JwtHeader, callback: SigningKeyCallback) {
  if (!header.kid) return callback(new Error("No kid in token header"), undefined);
  jwksClient.getSigningKey(header.kid, (err, key) => {
    if (err) return callback(err, undefined);
    const signingKey = key?.getPublicKey();
    callback(null, signingKey);
  });
}

export function authenticateOidc(req: Request, res: Response, next: NextFunction) {
  try {
    const token = extractBearerToken(req.headers);
    if (!token) return res.status(401).json({ error: "Missing bearer token" });
    jwt.verify(
      token,
      getKey,
      {
        audience: config.oidc.audience,
        issuer: config.oidc.issuer,
        algorithms: ["RS256"],
      },
      (err, decoded) => {
        if (err || !decoded) return res.status(401).json({ error: "Invalid token" });
        const d = decoded as DecodedToken;
        const rolesClaim = Array.isArray(d[config.oidc.rolesClaim as string])
          ? (d[config.oidc.rolesClaim as string] as string[])
          : [];
        const subjectId = (d[config.oidc.subjectIdClaim as string] as string) || d.tid || "";
        const user: AuthenticatedUser = {
          userId: d.sub,
          subjectId,
          roles: rolesClaim.includes("CAPOFILA") ? ["CAPOFILA"] : ["CONSORZIO"],
          email: (d.email as string) || (d.preferred_username as string),
          name: d.name as string,
        };
        (req as any).user = user;
        next();
      }
    );
  } catch (e) {
    return res.status(401).json({ error: "Unauthorized" });
  }
}

export function requireRole(role: "CAPOFILA" | "CONSORZIO") {
  return (req: Request, res: Response, next: NextFunction) => {
    const user = (req as any).user as AuthenticatedUser | undefined;
    if (!user) return res.status(401).json({ error: "Unauthorized" });
    if (!user.roles.includes(role)) return res.status(403).json({ error: "Forbidden" });
    next();
  };
}

function extractBearerToken(headers: IncomingHttpHeaders): string | undefined {
  const auth = headers.authorization || headers.Authorization;
  if (!auth) return undefined;
  const [scheme, token] = String(auth).split(" ");
  if (scheme.toLowerCase() !== "bearer") return undefined;
  return token;
}

