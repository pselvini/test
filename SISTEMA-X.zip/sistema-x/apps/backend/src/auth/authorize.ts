import { Request, Response, NextFunction } from "express";
import { AuthenticatedUser } from "../types";
import { repository } from "../repository/repository";

export async function authorizeSubjectAccess(req: Request, res: Response, next: NextFunction) {
  const user = (req as any).user as AuthenticatedUser | undefined;
  if (!user) return res.status(401).json({ error: "Unauthorized" });
  const subjectId = (req.params.subjectId || req.params.id) as string | undefined;
  if (!subjectId) return res.status(400).json({ error: "Missing subjectId" });
  if (user.roles.includes("CAPOFILA")) return next();
  if (user.subjectId === subjectId) return next();
  return res.status(403).json({ error: "Forbidden" });
}

export async function authorizeDocDownload(req: Request, res: Response, next: NextFunction) {
  const user = (req as any).user as AuthenticatedUser | undefined;
  if (!user) return res.status(401).json({ error: "Unauthorized" });
  const { repository: repo } = await import("../repository/repository");
  const doc = await repo.getDocument(req.params.id);
  if (!doc) return res.status(404).json({ error: "Not found" });
  if (user.roles.includes("CAPOFILA")) return next();
  if (user.subjectId === doc.subjectId) return next();
  return res.status(403).json({ error: "Forbidden" });
}

