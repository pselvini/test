import fs from "fs";
import path from "path";
import { config } from "../config";

export class StorageService {
  private root: string;
  constructor(rootDir?: string) {
    this.root = rootDir || config.storageRoot;
    fs.mkdirSync(this.root, { recursive: true });
  }

  private subjectDir(subjectId: string): string {
    const p = path.join(this.root, subjectId);
    fs.mkdirSync(p, { recursive: true });
    return p;
  }

  async saveFile(subjectId: string, filename: string, data: Buffer): Promise<string> {
    const dir = this.subjectDir(subjectId);
    const fullPath = path.join(dir, filename);
    await fs.promises.writeFile(fullPath, data);
    return fullPath;
  }

  async readFile(fullPath: string): Promise<Buffer> {
    return await fs.promises.readFile(fullPath);
  }
}

