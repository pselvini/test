import nodemailer from "nodemailer";
import { config } from "../config";

export interface EmailParams {
  to: string[];
  subject: string;
  text?: string;
  html?: string;
}

export class EmailService {
  private transporter = nodemailer.createTransport({
    host: config.email.smtpHost,
    port: config.email.smtpPort,
    secure: false,
    auth: config.email.smtpUser
      ? { user: config.email.smtpUser, pass: config.email.smtpPass }
      : undefined,
  });

  async send(params: EmailParams) {
    await this.transporter.sendMail({
      from: config.email.from,
      to: params.to.join(","),
      subject: params.subject,
      text: params.text,
      html: params.html,
    });
  }
}

