import fs from "fs";
import path from "path";
import { config } from "../config";

export type AuditAction =
  | "LOGIN"
  | "UPLOAD"
  | "DOWNLOAD"
  | "GENERATE_EXCEL"
  | "IMPORT_DATA"
  | "NOTIFY_EMAIL";

export interface AuditEntry {
  timestamp: string; // ISO
  subjectId?: string;
  userId?: string;
  action: AuditAction;
  resource?: string; // e.g., file path or endpoint
  outcome: "SUCCESS" | "FAILURE";
  notes?: string;
}

export class AuditService {
  private logPath: string = config.auditLogPath;
  constructor() {
    const dir = path.dirname(this.logPath);
    fs.mkdirSync(dir, { recursive: true });
  }

  async write(entry: AuditEntry) {
    const line = JSON.stringify(entry) + "\n";
    await fs.promises.appendFile(this.logPath, line, { encoding: "utf8" });
  }
}

