import { generateKeyPair, exportPKCS8, exportSPKI, SignJWT, importPKCS8 } from "jose";
import fs from "fs";

export interface SubjectKeyPair {
  privateKeyPem: string;
  publicKeyPem: string;
}

export async function generateSubjectKeyPair(): Promise<SubjectKeyPair> {
  const { privateKey, publicKey } = await generateKeyPair("RS256");
  const privateKeyPem = await exportPKCS8(privateKey);
  const publicKeyPem = await exportSPKI(publicKey);
  return { privateKeyPem, publicKeyPem };
}

export async function signBufferDetachedJws(buffer: Buffer, privateKeyPem: string): Promise<string> {
  const privateKey = await importPKCS8(privateKeyPem, "RS256");
  const payload = {
    hash: await cryptoDigest(buffer),
    size: buffer.length,
  } as const;
  const jws = await new SignJWT(payload as any)
    .setProtectedHeader({ alg: "RS256", typ: "JWS" })
    .setIssuedAt()
    .sign(privateKey);
  return jws;
}

export async function writeSignatureFile(signaturePath: string, jws: string): Promise<void> {
  await fs.promises.writeFile(signaturePath, jws, { encoding: "utf8" });
}

async function cryptoDigest(data: Buffer): Promise<string> {
  const subtle = (globalThis as any).crypto?.subtle || (await import("crypto")).webcrypto.subtle;
  const digest = await subtle.digest("SHA-256", data);
  return Buffer.from(digest).toString("hex");
}

