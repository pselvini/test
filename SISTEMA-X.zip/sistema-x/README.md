SISTEMA-X

Applicazione web per area di scambio dati tra CAPOFILA e N CONSORZI con autenticazione OIDC (MS Entra ID), caricamento/scaricamento documenti (PDF/Excel), firma JWS, generazione Excel per anno, notifiche email e audit log.

Struttura
- apps/backend: API Express TypeScript
- apps/frontend: React + Vite + MSAL

Avvio (sviluppo)
1) Backend
```bash
cd apps/backend
cp .env.example .env
npm run dev
```
2) Frontend
```bash
cd apps/frontend
cp .env.local .env.local
# compilare VITE_MSAL_CLIENT_ID e VITE_MSAL_TENANT_ID
npm run dev
```

API principali
- GET /health
- POST /v1/subjects (CAPOFILA): crea soggetto e chiavi
- POST /v1/subjects/:subjectId/users (CAPOFILA): aggiunge utenti
- GET /v1/spaces: spazi visibili
- GET /v1/subjects/:subjectId/documents: lista documenti
- POST /v1/subjects/:subjectId/documents: upload (PDF/XLSX) con firma
- GET /v1/documents/:id/download: download
- POST /v1/ingest: importa dati master da API esterna
- POST /v1/generate/:year (CAPOFILA): genera Excel per consorzi e notifica
- GET /v1/consorzi/:id/data/:year: JSON firmato (JWS)

Nota: OIDC, Oracle e SMTP sono predisposti; in questo scaffold repository e storage sono in-memory/filesystem.
